from src.init_config import launcher
from pyspark.sql.types import *
from pyspark.dbutils import DBUtils

def run_tablon_analytics(project_data, **_):



    return None


if __name__ == "__main__":
    launcher(run_tablon, init_spark=True, use_databricks_spark=True)
